﻿DragonWarriorMonsterZoneEditor 1.0.0.26604
Coded by: Shawn M. Crawford [sleepy9090]
February 18, 2018

-Requires .NET Framework 3.5

DragonWarriorEquipmentAndMagicDataEditor 
Program to edit the monsters that appear in any of the 20 different zones in the NES ROM Dragon Warrior.

-Tested with headered Dragon Warrior (U) (PRG0) [!].nes ROM.
-Tested with headered Dragon Warrior (U) (PRG1) [!].nes ROM.

Feel free to send bugs to sleepy3d@email.com or file them on github: https://github.com/sleepy9090

Version: 1.0.0.26604 February 18, 2018
-initial version


